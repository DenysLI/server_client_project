/********************************************************************
 *  File: Client 
 *  Function: Input Server IP address and Port to connect Server.
 *            Input file name to read its content.
 *******************************************************************/

#include <stdio.h>
#include <winsock.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

// ********************* MACRO Defines ******************************
#define SEND_LENGTH     1024
#define RECEIVE_LENGTH  1024
#define RECORD_LENGTH   1024
#define DEBUG_PRINTF    1
#define RECORD_PRINTF   1
#define FILE_PATH       "C:\\clientfile\\"

int is_ipv4_addr(char *ip);
int is_ipv4_port(char *port);
void rcd_ip_port(char * server_ip, int server_port);
void rcd_intervals(int receive_intervals);
void rcd_information(char * ptr_info);
void rcd_informations(char * ptr_info_1, char * ptr_info_2, char * ptr_info_3);
void rcd_receive_times(char *record_buf, int receive_times);

/******************************* main function ***********************************
  * function： program entry: main(). 
*/
int main(void)
{     
    WORD wversion_requested; // parameters about windows socket library
    WSADATA wsa_data;    
    int error;
    char server_ip[20];      // parameters about IP address and Port
    int server_port;
    char server_portString[10] ;
    SOCKET socket_send;     // parameters about socket
    SOCKADDR_IN server_addr;   
    char send_buf[SEND_LENGTH];
    char receive_buf[RECEIVE_LENGTH];
    char read_buf[RECEIVE_LENGTH];
    char record_buf[RECORD_LENGTH];
    char file_buff[1024];
    int send_len;
    int receive_len;
    int receive_times;
    int receive_intervals;
    char interval_string[10];
    FILE *fp = NULL;        // parameters about file
    FILE *fp_rcd = NULL;
    char file_path[100];
    int i;

    /* To use sockets in Windows, we need to load the socket library (socket environment) first
	(WSAStartup) , and release the socket resources in the end.(WSACleanup)*/
    wversion_requested = MAKEWORD(2, 2);
    error = WSAStartup(wversion_requested, &wsa_data);
    if (error != 0) {
        printf("WSAStartup fail with error: %d\n", error);
        return 0;
    }
 
    if (LOBYTE(wsa_data.wVersion)!=2 || HIBYTE(wsa_data.wVersion)!=2) {
        WSACleanup();
        return 0;
    }

#if(RECORD_PRINTF == 1)
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "w+"); // open file in w+ mode
    fputs("record of communication process of Client.\n", fp_rcd);
    fclose(fp_rcd);
#endif

    // Input Server IP address and PORT
    printf("Please input Server IP you will connect:");
    scanf("%s", server_ip);
    while(is_ipv4_addr(server_ip) == -1) {
        printf("IP address is invalid!\n");   
        printf("Please input Server IP you will connect:");
        scanf("%s", server_ip);
    }

    printf("Please input Server Port: ");
    scanf("%s", server_portString);
    while(is_ipv4_port(server_portString) == -1) {
        printf("Port number is invalid!\n");   
        printf("Please input Port number (0~65535):");
        scanf("%s", server_portString);
    }    
    server_port = is_ipv4_port(server_portString);
    rcd_ip_port(server_ip, server_port);

    printf("Repeat Intervals(0~600, unit:seconds): 0 presents no repeat.\n");
    printf("Please input repeat intervals: ");
    scanf("%d", &receive_intervals); 
    rcd_intervals(receive_intervals);

    if(receive_intervals > 600) {
        receive_intervals = 600;
        printf("the intervals will be set to 600.\n ");
        rcd_information("the intervals is bigger than 600 and will be reset to 600.\n ");
    }

    printf("Now connect to Server, Please wait...\n"); 
    rcd_information("connect to Server...\n");


    // *Client read file from Server
    // step_1: build socket according input parameters.   

    server_addr.sin_addr.S_un.S_addr = inet_addr((char *)server_ip);    
    server_addr.sin_port = htons(server_port);
    server_addr.sin_family = AF_INET;
    socket_send = socket(AF_INET, SOCK_STREAM, 0);

    // step_2: connect 
    if (connect(socket_send, (SOCKADDR*)&server_addr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
        printf("Connect failure.\n");
        rcd_information("Connect failure.\n");
         WSACleanup();
        Sleep(3000); // sleep 3000 ms
        return 0;    // then close the Client window
    }

    receive_times = 0; 
    while (1)
    {
        // step_3: Input the file name and send to Server
        // receive_intervals equals 0 indicates no repeat.
        if(receive_intervals == 0) { 
            printf("Please enter file name to read:");
            scanf("%s", send_buf);
            rcd_informations("Interval is 0, No automatic.\n", "input file name:", \
                            send_buf);
            if(strcmp(send_buf, "exit") == 0) {
                printf("Program exit following exit command!\n");
                Sleep(2000); // sleep 2000 ms
                rcd_information("Program exit following exit command!\n");
                break;
            }
        }
        // Others indicates repeat. fistly wait for use input file name
        else if (receive_times == 0) {                     
            printf("Please enter file name to read:");
            scanf("%s", send_buf);
            rcd_informations("Interval is not 0, automatic, input file name firstly.\n", \
                             "input file name:", send_buf);          
            if(strcmp(send_buf, "exit") == 0) {
                printf("Program exit!\n");
                rcd_information("Program exit following exit command!\n");               
                Sleep(2000); // sleep 2000 ms
                break;
            }
            receive_times++;
        }
        // wait receive_intervals seconds, send file name autumatically.
        else {
            receive_times++;
            Sleep(receive_intervals*1000); // sleep receive_intervals seconds
            itoa(server_port, record_buf, 10);
            printf("%s", record_buf);
            printf(" Automatic send read command %d times.\n", receive_times);
            rcd_receive_times(record_buf, receive_times);
        }        
        //printf("\nPlease enter file name to read:");
        //scanf("%s", send_buf); 

        // step_4: recv() content from Server
        strcpy(receive_buf," ");
        //strcpy(file_buff, " ");
        i = 0;
        while(strcmp(receive_buf, "EOF")!= 0) {
            if(i == 1) {
                strcpy(file_buff, receive_buf);
            }
            else{
                strcat(file_buff, receive_buf); 
            }

            send_len = send(socket_send, send_buf, sizeof(send_buf), 0); 
            receive_len = recv(socket_send, receive_buf, 1024, 0);
            i++;
        }
        strcpy(receive_buf, file_buff);
        printf("Server says: %s\n", file_buff);

        /* if file name is correct(be stored in the Server), read the local file 
        and compare with data from Server: if not same, rewrite the file, or 
        ignore it. */
        if(strcmp(receive_buf,"File name is incorrect.") != 0 ) { // if the file exists in Server
            // produce absolute path of the file                     
            strcpy(file_path, FILE_PATH); // copy default path to file_path
            strcat(file_path, send_buf); // append file name to path, produce a absolute path
            if(DEBUG_PRINTF == 1) {
                printf("file path is %s \n", file_path);
            }

            // read the content of the file in r+ mode
            fp = fopen(file_path, "r+"); // open file in r+ mode
            // if file doesn't exist, build the file 
            if (fp == NULL) {            
                if(DEBUG_PRINTF == 1) {
                    //printf("read file failure, file is occupied or not exists.\n");
                    printf("read file failure, create the file in direcotry C:\\clientfile \n");
                }
                fp = fopen(file_path, "w+"); // open file in w+ mode (create a file) 
                fputs(receive_buf, fp);
                fclose(fp); 
                rcd_informations("read file failure, create the file in direcotry C:\\clientfile \n",\
                                  receive_buf, NULL);
              
            }
            else { // file exists in the directory
                fgets(read_buf, SEND_LENGTH, (FILE*)fp); // read file's content
                if(DEBUG_PRINTF == 1) {
                    printf("file's current content is: %snew content received is: %s\n", \
                           read_buf, receive_buf);
                }
                fclose(fp);  // file was opened in r+ mode  

                rcd_informations("file's current content is: ", read_buf, NULL);
                rcd_informations("new content received is: ", receive_buf, "\n");           

                // compare the file's content with new content received from Server                
                if(strcmp(receive_buf, read_buf) != 0) {  // if not same, create the file
                    fp = fopen(file_path, "w+");         
                    fputs(receive_buf, fp);              
                    fclose(fp);
                    rcd_information("receive new content, rebuild the file.\n ");                   
                }
            }
        }
        else { // if the file doesn't exist in Server
            if(DEBUG_PRINTF == 1) {
                printf("receive buffer is %s\n", receive_buf);            
            }
            rcd_informations("receive buffer is %s", receive_buf, NULL);            
        }
    }
    closesocket(socket_send); // close the socket
    Sleep(3000);
    WSACleanup(); //release the socket resources in the end.(WSACleanup)
    return 0;
}

/*****************************is_ipv4_addr() function ****************************
  * function： judge if the IP address pointed by *ip is valid.
  * return:    0 - valid IP, (-1) - invalid IP  
*/
int is_ipv4_addr(char *ip)
{
	if (ip == NULL || ip[0] == '0' || ip[0] == '\0') {
		return -1;
	}

	for (int i = 0, count = 0; i < strlen(ip); i++) {
		if ((ip[i] != '.') && (ip[i] < '0' || ip[i] > '9')) {
			return -1;
		}
		if (ip[i] == '.') {
			count++;
			if (count > 3) {
				return -1;
			}
		}
	}

	int ip_num[4] = {-1, -1, -1, -1};
	char ip_str[4][4];
	memset(ip_str, 0, sizeof(char[4]) * 4);

	sscanf(ip, "%[^.].%[^.].%[^.].%[^ ]", ip_str[0], ip_str[1], ip_str[2], ip_str[3]);
	sscanf(ip_str[0], "%d", &ip_num[0]);
	sscanf(ip_str[1], "%d", &ip_num[1]);
	sscanf(ip_str[2], "%d", &ip_num[2]);
	sscanf(ip_str[3], "%d", &ip_num[3]);

	for (int i = 0; i < 4; i++) {
		if (strlen(ip_str[i]) == 0 || (ip_str[i][0] == '0' && ip_str[i][1] != '\0') || ip_num[i] < 0 || ip_num[i] > 255) {
			return -1;
		}
	}

	return 0;
}

/*****************************is_ipv4_port() function ****************************
  * function： judge if the port number pointed by *port is valid.
  * return:    others - valid Port, (-1) - invalid Port  
*/
int is_ipv4_port(char *port)
{
    int temp_port;

	if (port[0] == '0' || port[0] == '\0') {
		return -1;
	}

	for (int i = 0, count = 0; i < strlen(port); i++) {
		if ((port[i] < '0' || port[i] > '9')) {
			return -1;
		}
	}
    sscanf(port, "%d", &temp_port);
    if(temp_port > 65535) {
        return -1;
    }

    return temp_port;
}

/*****************************rcd_ip_port functions ****************************
  * functions： record IP address and port information .
*/
void rcd_ip_port(char * server_ip, int server_port)
{
    char record_buf[RECORD_LENGTH];
    FILE *fp_rcd = NULL;

    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); // open file in a+ mode
    if(fp_rcd != NULL) {    
        fputs("input Server IP: ", fp_rcd); 
        fputs(server_ip, fp_rcd); 
        fputs("\n", fp_rcd); 
        fputs("input Server Port: ", fp_rcd); 
        itoa(server_port, record_buf, 10);
        fputs(record_buf, fp_rcd); 
        fputs("\n", fp_rcd);
        fclose(fp_rcd);
    }
}

/****************************rcd_intervals functions ***************************
  * functions： record intervals of automaitc sending read file command.
*/
void rcd_intervals(int receive_intervals)
{
    char record_buf[RECORD_LENGTH];
    FILE *fp_rcd = NULL;

#if(RECORD_PRINTF == 1) 
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+");
    if(fp_rcd != NULL) { 
        fputs("Repeat Intervals(0~600): ", fp_rcd); 
        itoa(receive_intervals, record_buf, 10);
        fputs(record_buf, fp_rcd); fputs("\n", fp_rcd);
        fclose(fp_rcd);
    }
#endif
}

/***************************rcd_receive_times functions ***************************
  * functions： record Server's response: receive times.
*/
void rcd_receive_times(char *record_buf, int receive_times)
{
    char rec_buf[RECORD_LENGTH];
    FILE *fp_rcd = NULL;

#if(RECORD_PRINTF == 1)
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
    if(fp_rcd != NULL) { 
        fputs(record_buf, fp_rcd); 
        fputs(" Automatic send read command:", fp_rcd);
        itoa(receive_times, rec_buf, 10);
        fputs(rec_buf, fp_rcd);
        fputs(" times.\n", fp_rcd);
        fclose(fp_rcd);
    }
#endif 
}

/***************************rcd_information functions ***************************
  * functions： record one information.
*/
void rcd_information(char * ptr_info)
{
    FILE *fp_rcd = NULL;

#if(RECORD_PRINTF == 1)
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
    if(fp_rcd != NULL) { 
        fputs(ptr_info, fp_rcd);    
        fclose(fp_rcd);
    }
#endif
}

/***************************rcd_informations functions ***************************
  * functions： record 3 piece of information.
*/
void rcd_informations(char * ptr_info_1, char * ptr_info_2, char * ptr_info_3)
{
    FILE *fp_rcd = NULL;

#if(RECORD_PRINTF == 1)
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+");
    if(fp_rcd != NULL) { 
        if(ptr_info_1 != NULL) {
            fputs(ptr_info_1, fp_rcd);
        } 
        if(ptr_info_2 != NULL) {
            fputs(ptr_info_2, fp_rcd);
        }
        if(ptr_info_3 != NULL) {
            fputs(ptr_info_3, fp_rcd);
        }
        fclose(fp_rcd);
    }
#endif
}
