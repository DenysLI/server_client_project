/*******************************************************************************
 *  File：Server
 *  Function: Display Server IP address and Port
 *            Display files name stored in the directory
 *            Send the file content to Client
 ******************************************************************************/
#include <stdio.h>
#include <winsock.h>
#include <process.h>
#include <string.h>
#include <pthread.h>
#include <windows.h>
#include <time.h>
#include <io.h>
#include <unistd.h>
//#include <winsock2.h>

// ******************************** macro define *******************************
#define FILE_PATH           "C:\\serverfile\\"
#define SEND_LENGTH         1024
#define RECEIVE_LENGTH      1024
#define RECORD_PRINTF       1
#define MAX_FILE_NUMBER     4

// **************************** global parameters define ***********************
const int server_ports[5] = {5006,5007,5008,5009,5010};
static char connect_number = 0;	// every child thread allocate a different port
char server_ip[25];
char rcdfile_busy = 0;          // file busy flag
char file_busy[MAX_FILE_NUMBER];
FILE *fp_rcd = NULL;            // record file handle pointer
char rcd_buff[1024];
char temp_buff[100];
char file_path[100];
char file_name[150];

// ****************************** function declaration *************************
//void * ethscan();
void *ethscan(void * current_port);
void * update_file();
int is_ipv4_addr(char *ip);
void server_build_files(void);
void rcd_ip_ports(char * server_ip);
void rcd_connect_failure(int current_port);
void * ethscan_child_thread(void * socket_receive);


/******************************* main function ***********************************
  * function： program entry: main(). 
*/
int main(void)
{
    FILE *fp = NULL; // parameter for file handle
    pthread_t tid_1, tid_2, tid_3, tid_4, tid_5, tid_update; // parameter for multithreading
    time_t t;	    // parameter for timer
	char ptime[50];
    unsigned long longserver_ip;   
    WORD version_requested;  // parameters for socket environment
    WSADATA wsa_data;
    int error;
	int i;
	struct _finddata_t file_info; // parameter for directory operation
    long fHandle;


	/* To use sockets in Windows, we need to load the socket library (socket environment) 
	first(WSAStartup) , and release the socket resources in the end.(WSACleanup)*/
	version_requested = MAKEWORD(2, 2);
    error = WSAStartup(version_requested, &wsa_data);	
    if (error != 0)
	{
		printf("WSAStartup failed with error: %d\n", error);
		return 0;
	}
	if (LOBYTE(wsa_data.wVersion) != 2 || HIBYTE(wsa_data.wVersion) != 2)
	{
		printf("Could not find a usable version of Winsock.dll\n");
		WSACleanup();
		return 0;
	}	

	for(i=0; i<4; i++) {
		file_busy[i] = 0;
	}

	server_build_files();	// get files in Server

    // records Server build 4 new files
#if(RECORD_PRINTF == 1)	
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "w+");
	if(fp_rcd != NULL) {
		fputs("Server WSAStartup run success.\n", fp_rcd);
		fputs("file's directory is C:\\serverfile\n", fp_rcd);
	    fclose(fp_rcd); 
	}
#endif	

    // indicates to input Server IP adress
    printf("Server is On!\n");
	printf("Please set Server IP: ");
    scanf("%s", server_ip);
    while(is_ipv4_addr(server_ip) == -1) {
        printf("IP address is invalid!\n");   
        printf("Please input Server IP you will connect:");
        scanf("%s", server_ip);
    }

	printf("Server's IP address is %s.\n", server_ip);
	if(inet_addr(server_ip) == -1)
	{
		printf("\nServer's IP is Invalid!!!  %s.\n");
		printf("Please restart the server and input Valid IP address. \n\n");
	}
    printf("Server Ports are: %d, %d, %d, %d, %d.\n", server_ports[0], server_ports[1],\
            server_ports[2],  server_ports[3],  server_ports[4]);
	printf("Please connect Server and input the file name you want to receive:\n");

    rcd_ip_ports(server_ip); // records Server IP adress and Ports

    // input directory and print the files in the directory.
    printf("Please input file's path: ");
	scanf("%s", file_path);
    strcpy(file_name, file_path);
    strcat(file_name, "*.txt");
    printf("file path is %s.\n", file_name);	
	if( (fHandle=_findfirst( file_name, &file_info )) == -1L ) 
    {
        printf( "there is no txt file in current directory.\n");
        return 0;
    }
    else{
		i = 0;
        do{
            i ++;
            printf( "find file:%s, file zise:%d\n", file_info.name, file_info.size);
        }while( _findnext(fHandle, &file_info)==0);
    }
    _findclose( fHandle );
	printf("file number is %d\n", i);
    
    // builds 3 ethscan threads and 1 update_file thread.
    pthread_create(&tid_1, NULL, &ethscan, (void *)(&server_ports[0]));
    pthread_create(&tid_2, NULL, &ethscan, (void *)(&server_ports[1]));
    pthread_create(&tid_3, NULL, &ethscan, (void *)(&server_ports[2]));
	pthread_create(&tid_4, NULL, &ethscan, (void *)(&server_ports[3]));
    pthread_create(&tid_5, NULL, &ethscan, (void *)(&server_ports[4]));
	pthread_create(&tid_update, NULL, &update_file, NULL);

	// records Server builds 4 threads
#if(RECORD_PRINTF == 1)
    while(rcdfile_busy == 1){}
	rcdfile_busy = 1;
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	if(fp_rcd != NULL) {
	    fputs("Server Build 3 ethscan threads and 1 update_file thread.\n", fp_rcd); 
	    fclose(fp_rcd);
	}
	rcdfile_busy = 0;
#endif
	
	// block main thread and wait for child threads to finish executing.
    pthread_join(tid_1, NULL);   
    pthread_join(tid_2, NULL);
    pthread_join(tid_3, NULL);
	pthread_join(tid_4, NULL);
    pthread_join(tid_5, NULL);    
	pthread_join(tid_update, NULL); 

    // release the socket resources.
	WSACleanup();    
	return 0;    
}

/******************************* update_file ***********************************
  * function： update the files with local current clock every 5000 ms. 
*/
void * update_file()
{
	time_t t;
    char * ptime;
	FILE *fp = NULL;
	FILE *fp_rcd = NULL;

    while(1)
    {
        t = time(NULL);
        ptime = ctime(&t);

        while(file_busy[0] == 1) {}
		file_busy[0] = 1;
     	fp = fopen("C:\\serverfile\\good.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are good!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
        file_busy[0] = 0;

		while(file_busy[1] == 1) {}
		file_busy[1] = 1;
	    fp = fopen("C:\\serverfile\\friend.txt", "w+");
		if(fp != NULL) {
	        fputs(" We are good friends.", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
		file_busy[1] = 0;

        while(file_busy[2] == 1) {}
		file_busy[2] = 1;
	    fp = fopen("C:\\serverfile\\better.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are getting better!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
		file_busy[2] = 0;

        while(file_busy[3] == 1) {}
		file_busy[3] = 1;
	    fp = fopen("C:\\serverfile\\best.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are the best!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		} 
		file_busy[3] = 0;

		// record Server creates 4 files
#if(RECORD_PRINTF == 1)
        while(rcdfile_busy == 1){}
	    rcdfile_busy = 1;
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
		if(fp_rcd != NULL) {
			fputs("Update 4 file.\n", fp_rcd);
	        fclose(fp_rcd);
		} 
		rcdfile_busy = 0; 
#endif 
        Sleep(5000); // sleep 5000 ms
    }
}

/*********************************** ethscan **********************************
  * function： scan and wait request from client to build a connection . 
*/
void *ethscan(void * current_port)
{
    char send_buff[SEND_LENGTH];
    char receive_buff[RECEIVE_LENGTH];
	char file_buff[1024];
    int send_len;
    int receive_len;
    int length; 
	int receive_times = 0;
	char receive_timesBuf[11];
	FILE *fp = NULL;
    // int current_port;
    time_t t;
    char * ptime;
	u_short i;
	char temp_buff[20];
	char file_name[150];
	pthread_t tid[5];
 	
    SOCKET socket_server;
    //SOCKET socket_receive;
	SOCKET socket_rec_arr[5]; 
	int socket_rec_num = 0;
    SOCKADDR_IN server_addr;
    SOCKADDR_IN client_addr;

    // Server is multi_threading, each thread(connection) has a different PORT in sequence.
    /* current_port = server_ports[connect_number++ % 5]; // Server Port is transfered to 
	  ethscan(multithreading start_routine ) as a parameter */ 

    // Server connection
    // step_1: build socket according fixed IP and assigned PORT.
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.S_un.S_addr = inet_addr(server_ip);
	server_addr.sin_port = htons(*((int *)current_port));
	socket_server = socket(AF_INET, SOCK_STREAM, 0);
    
    // step_2: bind 
	if (bind(socket_server, (SOCKADDR*)&server_addr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		printf("Bind failure.\n");
	}
 
    // step_3: listen
	if (listen(socket_server, 5) < 0) {
		printf("Listen failure.\n");
	}
	
    // step_4: waiting to accept the client's connection request
	length = sizeof(SOCKADDR);
	for(socket_rec_num = 0; socket_rec_num < 5; socket_rec_num ++) {
        socket_rec_arr[socket_rec_num] = accept(socket_server, (SOCKADDR*)&client_addr, &length);
		if (socket_rec_arr[socket_rec_num]  == SOCKET_ERROR)	{
		    printf("Accept connection failure.");
		}
		pthread_create(&tid[socket_rec_num], NULL, &ethscan_child_thread, (void *)(&socket_rec_arr[socket_rec_num]));
	}

	pthread_join(tid[0], NULL); 
	pthread_join(tid[1], NULL); 
	pthread_join(tid[2], NULL); 
	pthread_join(tid[3], NULL); 
	pthread_join(tid[4], NULL); 

	
	//closesocket(socket_receive);
	closesocket(socket_rec_arr[0]);
	closesocket(socket_rec_arr[1]);
	closesocket(socket_rec_arr[2]);
    closesocket(socket_rec_arr[3]);
    closesocket(socket_rec_arr[4]);
	closesocket(socket_server);
}

/*****************************is_ipv4_addr() function ****************************
  * function： judge if the IP address pointed by *ip is valid.
  * return:    0 - valid IP, (-1) - invalid IP  
*/
int is_ipv4_addr(char *ip)
{
	if (ip == NULL || ip[0] == '0' || ip[0] == '\0') {
		return -1;
	}

	for (int i = 0, count = 0; i < strlen(ip); i++) {
		if ((ip[i] != '.') && (ip[i] < '0' || ip[i] > '9')) {
			return -1;
		}
		if (ip[i] == '.') {
			count++;
			if (count > 3) {
				return -1;
			}
		}
	}

	int ip_num[4] = {-1, -1, -1, -1};
	char ip_s[4][4];
	memset(ip_s, 0, sizeof(char[4]) * 4);

	sscanf(ip, "%[^.].%[^.].%[^.].%[^ ]", ip_s[0], ip_s[1], ip_s[2], ip_s[3]);
	sscanf(ip_s[0], "%d", &ip_num[0]);
	sscanf(ip_s[1], "%d", &ip_num[1]);
	sscanf(ip_s[2], "%d", &ip_num[2]);
	sscanf(ip_s[3], "%d", &ip_num[3]);

	for (int i = 0; i < 4; i++) {
		if (strlen(ip_s[i]) == 0 || (ip_s[i][0] == '0' && ip_s[i][1] != '\0') || ip_num[i] < 0 || ip_num[i] > 255) {
			return -1;
		}
	}

	return 0;
}

/************************server_build_files() function *************************
  * function： build 4 files in C:\serverfile.
*/
void server_build_files(void)
{
	FILE *fp = NULL;

    // builds 4 files for Server to transfer.
	fp = fopen("C:\\serverfile\\good.txt", "w+");
	fputs(" You are good!", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\friend.txt", "w+");
	fputs(" We are good friends.", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\better.txt", "w+");
	fputs(" You are getting better!", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\best.txt", "w+");
	fputs(" You are the best!", fp);
	fclose(fp); 
}

/************************rcd_ip_ports() function *************************
  * function： record IP address and default Ports in file.
*/
void rcd_ip_ports(char * server_ip)
{
    char rcd_buff[100];
	char temp_buff[10];
    FILE *fp_rcd = NULL;

#if(RECORD_PRINTF == 1)	
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	if(fp_rcd != NULL) {
		fputs("Server IP:", fp_rcd); 
		fputs(server_ip, fp_rcd); 
		fputs("\n", fp_rcd);

		strcpy(rcd_buff, "Ports:");
		for(int i=0; i<5; i++) {
        	itoa(server_ports[i], temp_buff, 10);
			strcat(rcd_buff, temp_buff);
			strcat(rcd_buff, ",");
		}
		strcat(rcd_buff, "\n");
		fputs(rcd_buff, fp_rcd);
		fclose(fp_rcd);
	}
#endif	
}

/************************rcd_connect_failure() function *************************
  * function： record connection failure information.
*/
void rcd_connect_failure(int current_port)
{
	char rcd_buff[100];
	char temp_buff[10];
    FILE *fp_rcd = NULL;

    // records connect failure
#if(RECORD_PRINTF == 1)		
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	if(fp_rcd != NULL) {
		itoa(current_port, temp_buff, 10);
		strcpy(rcd_buff, temp_buff);
		strcat(rcd_buff, " connection failure.");
		fputs(rcd_buff, fp_rcd);
		fclose(fp_rcd);
	}
#endif
}

/************************ethscan_child_thread() function *************************
  * function： child thread of ethscan(). accomplish one port has multithread
  * parameter: receive socket
*/
void * ethscan_child_thread(void *socket_receive)
{
	char receive_buff[1024];
	char send_buff[SEND_LENGTH];
	int receive_len;
	int send_len;
	int receive_times = 0;
	char receive_timesBuf[20];
	FILE *fp = NULL;
	char * ptime;
	time_t t;
	u_short i;

	while (1)
	{
        // get local clock
        t = time(NULL);
        ptime = ctime(&t); 
        
		// step_5: waiting to receive data from the connection
		receive_len = recv(*((SOCKET *)socket_receive), receive_buff, RECEIVE_LENGTH, 0);
		if (receive_len < 0) {
			printf("Receive failure.\n");
			printf("Program Exit!\n");
            Sleep(5000); // display program exit notes for 5000 ms
			break;
		}
		else {
            //printf("%d ",current_port);
			printf("client says: %s, ", receive_buff);
            strcpy(file_name, file_path);
			strcat(file_name, receive_buff);			

			// example format: 5006 client say: good.txt,
#if(RECORD_PRINTF == 1)
			strcpy(rcd_buff, " client says: ");
			strcat(rcd_buff, receive_buff);
			strcat(rcd_buff, ", ");
#endif
		}        
		
        receive_times++;	
		itoa(receive_times, receive_timesBuf, 10);
        strcat(receive_timesBuf, " times,\n");
		printf("%s", receive_timesBuf);		

        // records content from Client
#if(RECORD_PRINTF == 1)
        while(rcdfile_busy == 1){}
	    rcdfile_busy = 1;
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			fputs(rcd_buff, fp_rcd);  // record content, example format: 5--6 client say: good.txt,
			itoa(receive_times, receive_timesBuf, 10);
            strcat(receive_timesBuf, " times, ");
			fputs(receive_timesBuf, fp_rcd);
			fclose(fp_rcd);
		}
		rcdfile_busy = 0;
#endif

        fp = NULL;
        fp = fopen(file_name, "r");
		printf("send file content: \n");
        i = 0;
        while(fgets(send_buff, SEND_LENGTH, (FILE*)fp) != NULL) {
	        send_len = send(*((SOCKET *)socket_receive), send_buff, sizeof(send_buff), 0);	
	        printf("%s", send_buff);
	        receive_len = recv(*((SOCKET *)socket_receive), receive_buff, RECEIVE_LENGTH, 0);
		}
	    strcpy(send_buff, "EOF");
	    send_len = send(*((SOCKET *)socket_receive), send_buff, sizeof(send_buff), 0);
        fclose(fp);

		// records file content
#if(RECORD_PRINTF == 1)	
        while(rcdfile_busy == 1){}
	    rcdfile_busy = 1;	
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			fputs(send_buff, fp_rcd);
			fclose(fp_rcd);
		}
	    rcdfile_busy = 0;
#endif	
	}
	return NULL;
}