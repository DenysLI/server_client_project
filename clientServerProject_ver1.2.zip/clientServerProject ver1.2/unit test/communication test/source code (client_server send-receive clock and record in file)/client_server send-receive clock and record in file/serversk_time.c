/******************************************************
 *  Server
 ****************************************************/
#include <stdio.h>
#include <winsock.h>
#include <process.h>
#include <string.h>

//#include <winsock2.h>
//#pragma comment(lib, "Ws2_32.lib")

#define SEND_LENGTH     1056
#define RECEIVE_LENGTH  1056
//#define SERVER_IP		INADDR_ANY	// binds socket to all available interfaces
#define SERVER_IP		"127.0.0.1"
#define SERVER_PORT     5050		// the port number had better bigger than 1000
#define WR_TIME_IN_FILE  1

int main()
{
    //pthread_t stPid = 0;
    char Sendbuf[SEND_LENGTH];
    char Receivebuf[RECEIVE_LENGTH];
    int SendLen;
    int ReceiveLen;
    int Length; 
	int ReceiveTimes = 0;
	char ReceiveTimesBuf[11];
	FILE *fp = NULL;
	char * filepath = "D:\\serverfile\\";
 	
    SOCKET socket_server;
    SOCKET socket_receive;
 
    SOCKADDR_IN Server_add;
    SOCKADDR_IN Client_add;
 
    WORD wVersionRequested;
    WSADATA wsaData;
    int error;

	wVersionRequested = MAKEWORD(2, 2);	
    error = WSAStartup(wVersionRequested, &wsaData);	
    if (error != 0)
	{
		printf("WSAStartup failed with error: %d\n", error);
		return 0;
	}
	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
	{
		printf("Could not find a usable version of Winsock.dll\n");
		WSACleanup();
		return 0;
	}

    // Build 4 files for Server to transfer.
	if(WR_TIME_IN_FILE != 1)
	{
	    fp = fopen("D:\\serverfile\\good.txt", "w+");
	    fputs(" You are good!", fp);
	    fclose(fp);
	    fp = fopen("D:\\serverfile\\friend.txt", "w+");
	    fputs(" We are good friends.", fp);
	    fclose(fp);
	    fp = fopen("D:\\serverfile\\better.txt", "w+");
	    fputs(" You are getting better!", fp);
	    fclose(fp);
	    fp = fopen("D:\\serverfile\\best.txt", "w+");
	    fputs(" You are the best!", fp);
	    fclose(fp); 
	}
	else
	{
        fp = fopen("C:\\tmp\\server_receive_time_record.txt", "w+");
	    fputs(" Record content sent from Client.\n", fp);
	    fclose(fp);
	}

	Server_add.sin_family = AF_INET;
	//Server_add.sin_addr.S_un.S_addr = htonl(SERVER_IP);
	Server_add.sin_addr.S_un.S_addr = inet_addr(SERVER_IP);
	Server_add.sin_port = htons(SERVER_PORT);
	socket_server = socket(AF_INET, SOCK_STREAM, 0);

	if (bind(socket_server, (SOCKADDR*)&Server_add, sizeof(SOCKADDR)) == SOCKET_ERROR)
	{
		printf("Bind failure.\n");
	}
 
	if (listen(socket_server, 5) < 0)
	{
		printf("Listen failure.\n");
	}
	printf("Server is On!\n");
	printf("Server IP is %s, Server Port is %d.\n", SERVER_IP, SERVER_PORT);
	if(WR_TIME_IN_FILE != 1)
	{
	    printf("Please connect Server and input the file name you want to receive:\n");
	    printf("good.txt, friend.txt, better.txt, best.txt\n");

	}        
	//while(1)
    //{}

	Length = sizeof(SOCKADDR);
	socket_receive = accept(socket_server, (SOCKADDR*)&Client_add, &Length);
	if (socket_receive == SOCKET_ERROR)
	{
		printf("Accept connection failure.");
	}
	//while(1)  // see "Accept connection failure." in Server window
	//{}        // because another procedure is still running

	while (1)
	{
		ReceiveLen = recv(socket_receive, Receivebuf, RECEIVE_LENGTH, 0);
		if (ReceiveLen < 0)
		{
			printf("Receive failure.\n");
			printf("Program Exit!\n");
			//while(1){}
			break;
		}
		else
		{
			printf("client says: %s\n", Receivebuf);
		}
        ReceiveTimes++;	
		itoa(ReceiveTimes, ReceiveTimesBuf, 10);
        strcat(ReceiveTimesBuf, " times;");
		printf("%s", ReceiveTimesBuf);

		fp = fopen("C:\\tmp\\server_receive_time_record.txt", "a+");
		fputs(ReceiveTimesBuf, fp);
		fputs(Receivebuf, fp);
		fclose(fp);

        // *send package number that server received to client.
		itoa(ReceiveTimes, Sendbuf, 10);
		strcat(Sendbuf, " times;");
		SendLen = send(socket_receive, Sendbuf, 100, 0);	

        /*strcat(filepath, Receivebuf);
		printf(filepath);
		fp = fopen(filepath, "r");*/

		/*fp = NULL;
		if((strcmp(Receivebuf,"good.txt")==0) || (strcmp(Receivebuf,"good")==0))
		{
		    fp = fopen("D:\\serverfile\\good.txt", "r");
		}
		else if ((strcmp(Receivebuf,"friend.txt")==0) || (strcmp(Receivebuf,"friend")==0))
		{
		    fp = fopen("D:\\serverfile\\friend.txt", "r");
		}	
		else if ((strcmp(Receivebuf,"better.txt")==0) || (strcmp(Receivebuf,"better") == 0))
		{
		    fp = fopen("D:\\serverfile\\better.txt", "r");
		}	
		else if ((strcmp(Receivebuf,"best.txt")==0) || (strcmp(Receivebuf,"best")==0))
		{
		    fp = fopen("D:\\serverfile\\best.txt", "r");
		}	
		else
		{
			printf("File name is incorrect.");
			send(socket_receive, "File name is incorrect.", 50, 0);
			continue;
		}

		//fp = fopen("C:\\tmp\\file_rw_test.txt", "r");
        fgets(Sendbuf, SEND_LENGTH, (FILE*)fp);	
		printf("send content of the file be read: %s\n",Sendbuf);
        //SendLen = send(socket_receive, Sendbuf, SEND_LENGTH, 0);
		SendLen = send(socket_receive, Sendbuf, 100, 0);
		if (SendLen < 0)
		{
			printf("Send Failure\n");
		}
		fclose(fp);*/
	}
	closesocket(socket_receive);
	closesocket(socket_server);
	WSACleanup();

    printf("please enter message:2");
	//while(1){}
	return 0;
    
}




/*#include <stdio.h>
#include <winsock2.h>

#pragma comment (lib, "ws2_32.lib")  //加载 ws2_32.dll

int main(void)
{
    //初始化 DLL
    WSADATA wsaData;
    WSAStartup( MAKEWORD(2, 2), &wsaData);
    
    //创建套接字
    SOCKET servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    //绑定套接字
    struct sockaddr_in sockAddr;
    memset(&sockAddr, 0, sizeof(sockAddr));  //每个字节都用0填充
    sockAddr.sin_family = PF_INET;  //使用IPv4地址
    sockAddr.sin_addr.s_addr = inet_addr("127.0.0.1");  //具体的IP地址
    sockAddr.sin_port = htons(1234);  //端口
    bind(servSock, (SOCKADDR*)&sockAddr, sizeof(SOCKADDR));
    //进入监听状态
    listen(servSock, 20);
    //接收客户端请求
    SOCKADDR clntAddr;
    int nSize = sizeof(SOCKADDR);
    SOCKET clntSock = accept(servSock, (SOCKADDR*)&clntAddr, &nSize);
    //向客户端发送数据
    char *str = "Hello World!";
    send(clntSock, str, strlen(str)+sizeof(char), NULL);
    //关闭套接字
    closesocket(clntSock);
    closesocket(servSock);
    //终止 DLL 的使用
    WSACleanup();
    return 0;
}*/