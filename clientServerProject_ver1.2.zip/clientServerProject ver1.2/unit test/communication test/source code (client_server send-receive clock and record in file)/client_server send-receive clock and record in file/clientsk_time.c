#include<stdio.h>
#include<winsock.h>
#include <time.h>
#include <string.h>

#define SEND_LENGTH     1056
#define RECEIVE_LENGTH  1056


int main()
{
    char Sendbuf[SEND_LENGTH];
    char Receivebuf[RECEIVE_LENGTH];
    int SendLen;
    int ReceiveLen;
    FILE *fp = NULL;
    char * ptime;
    struct tm* ptr;
    time_t t;
    char ServerIP[25];
    //u_short ServerPort;
    int ServerPort;
 
    SOCKET socket_send;
    SOCKADDR_IN Server_add;
 
    WORD wVersionRequested;
    WSADATA wsaData;
    int error;
 
    wVersionRequested = MAKEWORD(2, 2);
    error = WSAStartup(wVersionRequested, &wsaData);
    if (error != 0)
    {
        printf("WSAStartup failed with error: %d\n", error);
        return 0;
    }
 
    if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
    {
        WSACleanup();
        return 0;
    }

    printf("Please input Server IP you will connect:");
    scanf("%s", ServerIP);
    printf("Please input Server Port:");
    scanf("%d", &ServerPort);
    printf("Now connect the Server, Please wait...\n");

 
    Server_add.sin_family = AF_INET;
    //Server_add.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
    //Server_add.sin_port = htons(5001);
    Server_add.sin_addr.S_un.S_addr = inet_addr((char *)ServerIP);    
    Server_add.sin_port = htons(ServerPort);
    socket_send = socket(AF_INET, SOCK_STREAM, 0);
 
    if (connect(socket_send, (SOCKADDR*)&Server_add, sizeof(SOCKADDR)) == SOCKET_ERROR)
    {
        printf("Connect failure.\n");
    }
 
    fp = fopen("C:\\tmp\\client_send_time_record.txt", "w+");
    fputs(" Record clock send to Server.\n", fp);
    fclose(fp);

    while (1)
    {
        // read current clock and write it to a file         
        fp = fopen("C:\\tmp\\client_send_time_record.txt", "a+");
        t = time(NULL);
        ptime = ctime(&t);
        fputs(ptime, fp);
        //fclose(fp);  

        SendLen = send(socket_send, ptime, 100, 0);
        if (SendLen < 0)
        {
            printf("Send operation failure.\n");
        }
        printf("Send to Server: %s\n",ptime);

        ReceiveLen = recv(socket_send, Receivebuf, 100, 0);
        if (ReceiveLen < 0)
        {
            printf("Receive operation failure.\n");
            printf("Program exit!\n");
            break;
        }
        else
        {
            printf("Server says: %s\n", Receivebuf);
        }
        fputs(Receivebuf, fp);
        fclose(fp); 

        Sleep(1000); // sleep 1000 ms

    }
    closesocket(socket_send);
    WSACleanup();
    return 0;
}