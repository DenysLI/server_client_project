1,  recording communication process about clock send and answer receive in txt format.

2,  Data items are separated by commas.

3,  change file format from txt to csv.

4, open csv file with excel.

5, in excel, we can analyze communicaiton quality.