1, user manual 
the manual file's name is "server_client_manual.xlsx", It consists of information about the Server&Client function, Server guide, Client guide, development process and version.

2, executable files
the "executable files" directory consists of executable files and its support library files.  Because multithreading and socket are used in Server development, it needs 2 dynamic link library files to support running.
C compiler type is GCC (MinGW), and its DLL files directory "bin" is copied into the DLL directory, if the system indicates any DLL is required, we search the .\dll\bin directory first.

3, source code
this directory includes the source code and the configuration file. The project is developed with Visual Studio Code, and the configuration files are stored in the directory ".vsnode".

4,  communication records
while Server and Client build connections and communicate, the communication process is recorded and stored in a file. The "communication records" record the communication process of these days.

5, unit test
this directory includes communication tests and multithreading tests. each test has record files. 




