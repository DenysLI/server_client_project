#include <stdio.h>
#include <string.h>
#include <pthread.h>
//#include <unistd.h>
#include <windows.h>

void *sample_1();
void *sample_2();


int main(void)
{
    pthread_t tid_1, tid_2;

    pthread_create(&tid_1, NULL, &sample_1, NULL);
    pthread_create(&tid_2, NULL, &sample_2, NULL);
    pthread_join(tid_1, NULL);
    pthread_join(tid_2, NULL);

}

void *sample()
{
    //char ReceiveBuff[100];
    char i;

    printf("Thread sample.\n");
    i = 0; 
    while(i < 10)
    {
        Sleep(1000);
    }
    //Sleep(1000);
    /*printf("Please enter 'exit' to close the sample.");
    while(TRUE)
    {
        scanf("%s",ReceiveBuff);
        if(strcmp(ReceiveBuff, "exit")==0)
        {
            break;
        }
    }*/
    printf("End Thread.\n");
}

void *sample_1()
{
    char i;

    printf("Thread sample_1.\n");
    i = 1; 
    while(i++ < 10)
    {
        Sleep(1000);
        printf("Thread sample_1 %d seconds.\n",i);
    }
    printf("End Thread sample_1.\n");
}

void *sample_2()
{
    char i;

    printf("Thread sample_2.\n");
    i = 1; 
    while(i++ < 10)
    {
        Sleep(1500);
        printf("Thread sample_2 %d seconds.\n",i);
    }
    printf("End Thread sample_2.\n");
}

