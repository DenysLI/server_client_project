/********************************************************************
 *  File: Client 
 *  Function: Input Server IP address and Port to connect Server.
 *            Input file name to read its content.
 *******************************************************************/

#include <stdio.h>
#include <winsock.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

// ********************* MACRO Defines ******************************
#define SEND_LENGTH     1024
#define RECEIVE_LENGTH  1024
#define RECORD_LENGTH   1024
#define DEBUG_PRINTF    1
#define RECORD_PRINTF   1
#define FILE_PATH       "C:\\clientfile\\"

#define RECORD_STRING(str,fp)   { printf(str); fputs(str,fp); }

int is_ipv4_addr(char *ip);
int is_ipv4_port(char *port);

/******************************* main function ***********************************
  * function： program entry: main(). 
*/
int main(void)
{     
    WORD wVersionRequested; // parameters about windows socket library
    WSADATA wsaData;    
    int error;
    char ServerIP[20];      // parameters about IP address and Port
    //u_short ServerPort;   // *u_short type will induce connection failure.
    int ServerPort;
    char ServerPortString[10] ;
    SOCKET socket_send;     // parameters about socket
    SOCKADDR_IN Server_add;   
    char SendBuf[SEND_LENGTH];
    char ReceiveBuf[RECEIVE_LENGTH];
    char ReadBuf[RECEIVE_LENGTH];
    char RecordBuf[RECORD_LENGTH];
    int SendLen;
    int ReceiveLen;
    int ReceiveTimes;
    int ReceiveIntervals;
    char IntervalString[10];
    FILE *fp = NULL;        // parameters about file
    FILE *fp_rcd = NULL;
    char filePath[100];
    //char * ptime1;        // parameters about timer
    //struct tm* ptr;
    //time_t t;

    int len;
    int i,j;
    int n;
    int dotnum;   

    /* To use sockets in Windows, we need to load the socket library (socket environment) first
	(WSAStartup) , and release the socket resources in the end.(WSACleanup)*/
    wVersionRequested = MAKEWORD(2, 2);
    error = WSAStartup(wVersionRequested, &wsaData);
    if (error != 0) {
        printf("WSAStartup fail with error: %d\n", error);
        return 0;
    }
 
    if (LOBYTE(wsaData.wVersion)!=2 || HIBYTE(wsaData.wVersion)!=2) {
        WSACleanup();
        return 0;
    }

#if(RECORD_PRINTF == 1)
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "w+"); // open file in w+ mode
    fputs("record of communication process of Client.\n", fp_rcd);
    fclose(fp_rcd);
#endif

    // Input Server IP address and PORT
    printf("Please input Server IP you will connect:");
    scanf("%s", ServerIP);
    while(is_ipv4_addr(ServerIP) == -1) {
        printf("IP address is invalid!\n");   
        printf("Please input Server IP you will connect:");
        scanf("%s", ServerIP);
    }

    printf("Please input Server Port: ");
    scanf("%s", ServerPortString);
    while(is_ipv4_port(ServerPortString) == -1) {
        printf("Port number is invalid!\n");   
        printf("Please input Port number (0~65535):");
        scanf("%s", ServerPortString);
    }    
    ServerPort = is_ipv4_port(ServerPortString);
    
#if(RECORD_PRINTF == 1)
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); // open file in a+ mode 
    fputs("input Server IP: ", fp_rcd); 
    fputs(ServerIP, fp_rcd); 
    fputs("\n", fp_rcd); 
    fputs("input Server Port: ", fp_rcd); 
    itoa(ServerPort, RecordBuf, 10);
    fputs(RecordBuf, fp_rcd); fputs("\n", fp_rcd);
    fclose(fp_rcd);
#endif

    printf("Repeat Intervals(0~600, unit:seconds): 0 presents no repeat.\n");
    printf("Please input repeat intervals: ");
    scanf("%d", &ReceiveIntervals); 

#if(RECORD_PRINTF == 1) 
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+");
    fputs("Repeat Intervals(0~600): ", fp_rcd); 
    itoa(ReceiveIntervals, RecordBuf, 10);
    fputs(RecordBuf, fp_rcd); fputs("\n", fp_rcd);
    fclose(fp_rcd);
#endif

    if(ReceiveIntervals > 600) {
        ReceiveIntervals = 600;
        printf("the intervals will be set to 600.\n ");
#if(RECORD_PRINTF == 1)
        fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
        fputs("the intervals is bigger than 600 and will be reset to 600.\n ", fp_rcd);
        fclose(fp_rcd);
#endif
    }

    printf("Now connect to Server, Please wait...\n");    
#if(RECORD_PRINTF == 1)
    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
    fputs("connect to Server...\n", fp_rcd); 
    fclose(fp_rcd);    
#endif 
    // *Client read file from Server
    // step_1: build socket according input parameters.   

    // v0.1 Set default IP address and Port
    Server_add.sin_addr.S_un.S_addr = inet_addr((char *)ServerIP);    
    Server_add.sin_port = htons(ServerPort);
    Server_add.sin_family = AF_INET;
    socket_send = socket(AF_INET, SOCK_STREAM, 0);

    // step_2: connect 
    if (connect(socket_send, (SOCKADDR*)&Server_add, sizeof(SOCKADDR)) == SOCKET_ERROR) {
        printf("Connect failure.\n");
#if(RECORD_PRINTF == 1) 
        fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
        fputs("Connect failure.\n", fp_rcd);
        fclose(fp_rcd);
#endif
        //printf("Please check the server's IP address and Port.\n");
        //Sleep(3000); // sleep 3000 ms
        //return 0;    // then close the Client window
    }

    ReceiveTimes = 0; 
    while (1)
    {
        // ReceiveIntervals equals 0 indicates no repeat.
        if(ReceiveIntervals == 0) {   
            // step_3: Input the file name and send to Server
            printf("Please enter file name to read:");
            scanf("%s", SendBuf);
#if(RECORD_PRINTF == 1)
            fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); // open file in a+ mode
            fputs("Interval is 0, No automatic.\n", fp_rcd);             
            fputs("input file name:", fp_rcd); 
            fputs(SendBuf, fp_rcd);
            fclose(fp_rcd);
#endif
            if(strcmp(SendBuf, "exit") == 0) {
                printf("Program exit following exit command!\n");
                Sleep(2000); // sleep 2000 ms
#if(RECORD_PRINTF == 1)
                fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); // open file in a+ mode
                fputs("Program exit following exit command!\n", fp_rcd);
                fclose(fp_rcd);
#endif
                break;
            }
        }
        // Others indicates repeat. fistly wait for use input file name
        else if (ReceiveTimes == 0) {                     
            printf("Please enter file name to read:");
            scanf("%s", SendBuf);
#if(RECORD_PRINTF == 1)
            fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
            fputs("Interval is not 0, automatic, input file name firstly.\n", fp_rcd);             
            fputs("input file name:", fp_rcd); 
            fputs(SendBuf, fp_rcd);
            fclose(fp_rcd);
#endif            
            if(strcmp(SendBuf, "exit") == 0) {
                printf("Program exit!\n");
#if(RECORD_PRINTF == 1)
                fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
                fputs("Program exit following exit command!\n", fp_rcd);
                fclose(fp_rcd);
#endif                
                Sleep(2000); // sleep 2000 ms
                break;
            }
            ReceiveTimes++;
        }
        // wait ReceiveIntervals seconds, send file name autumatically.
        else {
            ReceiveTimes++;
            Sleep(ReceiveIntervals*1000); // sleep ReceiveIntervals seconds
            itoa(ServerPort, RecordBuf, 10);
            printf("%s", RecordBuf);
            printf(" Automatic send read command %d times.\n", ReceiveTimes);
#if(RECORD_PRINTF == 1)
            fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
            fputs(RecordBuf, fp_rcd); 
            fputs(" Automatic send read command:", fp_rcd);
            itoa(ReceiveTimes, RecordBuf, 10);
            fputs(RecordBuf, fp_rcd);
            fputs(" times.\n", fp_rcd);
            fclose(fp_rcd);
#endif  
        }        
        //printf("\nPlease enter file name to read:");
        //scanf("%s", SendBuf); 
        SendLen = send(socket_send, SendBuf, 100, 0);
        if (SendLen < 0) {
            printf("Send operation failure.\n");
#if(RECORD_PRINTF == 1) 
            fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
            fputs("Send operation failure.\n", fp_rcd);
            fclose(fp_rcd);
#endif
        }

        // step_4: recv() content from Server
        ReceiveLen = recv(socket_send, ReceiveBuf, 100, 0);        
        if (ReceiveLen < 0) {
            printf("Receive operation failure.\n");
            printf("Program exit!\n");
#if(RECORD_PRINTF == 1) 
            fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
            fputs("Receive fail, prgram exit!\n", fp_rcd);
            fclose(fp_rcd);
#endif            
            Sleep(5000); // sleep 5000 ms
            break;
        }
        else {
            //printf("Server says: %s", ReceiveBuf);
#if(RECORD_PRINTF == 1)
            fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
            fputs("Server says: ", fp_rcd);
            fputs(ReceiveBuf, fp_rcd); 
            fclose(fp_rcd);
#endif
        }

        /* if file name is correct(be stored in the Server), read the local file 
        and compare with data from Server: if not same, rewrite the file, or 
        ignore it. */
        if(strcmp(ReceiveBuf,"File name is incorrect.") != 0 ) { // if the file exists in Server
            // produce absolute path of the file                     
            strcpy(filePath, FILE_PATH); // copy default path to filePath
            strcat(filePath, SendBuf); // append file name to path, produce a absolute path
            if(DEBUG_PRINTF == 1) {
                printf("file path is %s \n", filePath);
            }

            // read the content of the file in r+ mode
            fp = fopen(filePath, "r+"); // open file in r+ mode
            // if file doesn't exist, build the file 
            if (fp == NULL) {            
                if(DEBUG_PRINTF == 1) {
                    //printf("read file failure, file is occupied or not exists.\n");
                    printf("read file failure, create the file in direcotry C:\\clientfile \n");
                }
                fp = fopen(filePath, "w+"); // open file in w+ mode (create a file) 
                fputs(ReceiveBuf, fp);
                fclose(fp);                
#if(RECORD_PRINTF == 1)
                fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
                fputs("read file failure, create the file in direcotry C:\\clientfile \n", fp_rcd);
                fputs(ReceiveBuf, fp_rcd); 
                fclose(fp_rcd);
#endif                
            }
            else { // file exists in the directory
                fgets(ReadBuf, SEND_LENGTH, (FILE*)fp); // read file's content
                if(DEBUG_PRINTF == 1) {
                    //printf("file's current content is %s; new content received is %s", ReadBuf, ReceiveBuf);
                    printf("file's current content is: %snew content received is: %s\n", ReadBuf, ReceiveBuf);
                }
                fclose(fp);  // file was opened in r+ mode  

#if(RECORD_PRINTF == 1)
                fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
                fputs("file's current content is: ", fp_rcd);
                fputs(ReadBuf, fp_rcd);
                fputs("new content received is: ", fp_rcd); 
                fputs(ReceiveBuf, fp_rcd); fputs("\n", fp_rcd);
                fclose(fp_rcd);
#endif               

                // compare the file's content with new content received from Server                
                if(strcmp(ReceiveBuf, ReadBuf) != 0) {  // if not same, create the file
                    fp = fopen(filePath, "w+");         
                    fputs(ReceiveBuf, fp);              
                    fclose(fp);
#if(RECORD_PRINTF == 1)
                    fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
                    fputs("receive new content, rebuild the file.\n ", fp_rcd);
                    fclose(fp_rcd);
#endif                    
                }
            }
        }
        else { // if the file doesn't exist in Server
            if(DEBUG_PRINTF == 1) {
                printf("receive buffer is %s\n", ReceiveBuf);            
            }
#if(RECORD_PRINTF == 1)
            fp_rcd = fopen("C:\\clientfile\\clientRecord.txt", "a+"); 
            fputs("receive buffer is %s", fp_rcd);
            fputs(ReceiveBuf, fp_rcd);
            fclose(fp_rcd);
#endif            
        }
    }
    closesocket(socket_send); // close the socket
    Sleep(3000);
    WSACleanup(); //release the socket resources in the end.(WSACleanup)
    return 0;
}

/*****************************is_ipv4_addr() function ****************************
  * function： judge if the IP address pointed by *ip is valid.
  * return:    0 - valid IP, (-1) - invalid IP  
*/
int is_ipv4_addr(char *ip)
{
	if (ip == NULL || ip[0] == '0' || ip[0] == '\0') {
		return -1;
	}

	for (int i = 0, count = 0; i < strlen(ip); i++) {
		if ((ip[i] != '.') && (ip[i] < '0' || ip[i] > '9')) {
			return -1;
		}
		if (ip[i] == '.') {
			count++;
			if (count > 3) {
				return -1;
			}
		}
	}

	int ip_num[4] = {-1, -1, -1, -1};
	char ip_s[4][4];
	memset(ip_s, 0, sizeof(char[4]) * 4);

	sscanf(ip, "%[^.].%[^.].%[^.].%[^ ]", ip_s[0], ip_s[1], ip_s[2], ip_s[3]);
	sscanf(ip_s[0], "%d", &ip_num[0]);
	sscanf(ip_s[1], "%d", &ip_num[1]);
	sscanf(ip_s[2], "%d", &ip_num[2]);
	sscanf(ip_s[3], "%d", &ip_num[3]);

	for (int i = 0; i < 4; i++) {
		if (strlen(ip_s[i]) == 0 || (ip_s[i][0] == '0' && ip_s[i][1] != '\0') || ip_num[i] < 0 || ip_num[i] > 255) {
			return -1;
		}
	}

	return 0;
}

/*****************************is_ipv4_port() function ****************************
  * function： judge if the port number pointed by *port is valid.
  * return:    others - valid Port, (-1) - invalid Port  
*/
int is_ipv4_port(char *port)
{
    int tempport;

	if (port[0] == '0' || port[0] == '\0') {
		return -1;
	}

	for (int i = 0, count = 0; i < strlen(port); i++) {
		if ((port[i] < '0' || port[i] > '9')) {
			return -1;
		}
	}
    sscanf(port, "%d", &tempport);
    if(tempport > 65535) {
        return -1;
    }

    return tempport;
}
