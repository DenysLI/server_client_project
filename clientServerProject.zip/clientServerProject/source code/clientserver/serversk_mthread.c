/*******************************************************************************
 *  File：Server
 *  Function: Display Server IP address and Port
 *            Display files name stored in the directory
 *            Send the file content to Client
 ******************************************************************************/
#include <stdio.h>
#include <winsock.h>
#include <process.h>
#include <string.h>
#include <pthread.h>
#include <windows.h>
#include <time.h>
//#include <winsock2.h>

// ******************************** macro define *******************************
#define FILE_PATH       "C:\\serverfile\\"
#define SEND_LENGTH     1024
#define RECEIVE_LENGTH  1024
#define RECORD_PRINTF   1
#define MAX_FILE_NUMBER 4

// **************************** global parameters define ***********************
const int server_ports[5] = {5006,5007,5008,5009,5010};
static char connect_number = 0;		// every child thread allocate a different port
char ServerIP[25];
char rcdFileBusy = 0; // file busy flag
char fileBusy[MAX_FILE_NUMBER];
FILE *fp_rcd = NULL; // record file handle pointer
char rcdBuff[1024];
char tempBuff[100];

// ****************************** function declaration *************************
void * ethscan();
void * update_file();
int is_ipv4_addr(char *ip);


/******************************* main function ***********************************
  * function： program entry: main(). 
*/
int main(void)
{
    FILE *fp = NULL;
	//FILE *fp_rcd = NULL;
    pthread_t tid_1, tid_2, tid_3, tid_update;
    time_t t;
    //char * ptime;
	char ptime[50];
	//char * filepath = "D:\\serverfile\\";
    unsigned long longServerIP;
    WORD wVersionRequested;
    WSADATA wsaData;
    int error;
	char i;

	/* To use sockets in Windows, we need to load the socket library (socket environment) 
	first(WSAStartup) , and release the socket resources in the end.(WSACleanup)*/
	wVersionRequested = MAKEWORD(2, 2);
    error = WSAStartup(wVersionRequested, &wsaData);	
    if (error != 0)
	{
		printf("WSAStartup failed with error: %d\n", error);
		return 0;
	}
	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
	{
		printf("Could not find a usable version of Winsock.dll\n");
		WSACleanup();
		return 0;
	}	

	for(i=0; i<4; i++) {
		fileBusy[i] = 0;
	}

    // builds 4 files for Server to transfer.
	fp = fopen("C:\\serverfile\\good.txt", "w+");
	fputs(" You are good!", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\friend.txt", "w+");
	fputs(" We are good friends.", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\better.txt", "w+");
	fputs(" You are getting better!", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\best.txt", "w+");
	fputs(" You are the best!", fp);
	fclose(fp); 

    // records Server build 4 new files
#if(RECORD_PRINTF == 1)	
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "w+");
	if(fp_rcd != NULL) {
		fputs("windows socket environment function WSAStartup run success.\n", fp_rcd);
		fputs("build file---C:\\serverfile\\good.txt\n", fp_rcd);
	    fputs("build file---C:\\serverfile\\better.txt\n", fp_rcd); 
	    fputs("build file---C:\\serverfile\\best.txt\n", fp_rcd); 
	    fputs("build file---C:\\serverfile\\friend.txt\n", fp_rcd); 
	    fclose(fp_rcd); 
	}
#endif
	

    // indicates to input Server IP adress
    printf("Server is On!\n");
	printf("Please set Server IP: ");
    scanf("%s", ServerIP);
    while(is_ipv4_addr(ServerIP) == -1) {
    printf("IP address is invalid!\n");   
    printf("Please input Server IP you will connect:");
    scanf("%s", ServerIP);
    }

	printf("Server's IP address is %s.\n", ServerIP);
	if(inet_addr(ServerIP) == -1)
	{
		printf("\nServer's IP is Invalid!!!  %s.\n");
		printf("Please restart the server and input Valid IP address. \n\n");
	}
    printf("Server Ports are: %d, %d, %d.\n", server_ports[0], server_ports[1],\
            server_ports[2]);
	printf("Please connect Server and input the file name you want to receive:\n");
	printf("good.txt, friend.txt, better.txt, best.txt\n");  

    // records Server IP adress and Ports
#if(RECORD_PRINTF == 1)	
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	if(fp_rcd != NULL) {
		fputs("Server IP:", fp_rcd); 
		fputs(ServerIP, fp_rcd); 
		fputs("\n", fp_rcd);
		strcpy(rcdBuff, "Ports:");
		for(i=0; i<5; i++) {
        	itoa(server_ports[i], tempBuff, 10);
			strcat(rcdBuff, tempBuff);
			strcat(rcdBuff, ",");
		}
		strcat(rcdBuff, "\n");
		fputs(rcdBuff, fp_rcd);
		fclose(fp_rcd);
	}
#endif	 

    // builds 3 ethscan threads and 1 update_file thread.
    pthread_create(&tid_1, NULL, &ethscan, NULL);
    pthread_create(&tid_2, NULL, &ethscan, NULL);
    pthread_create(&tid_3, NULL, &ethscan, NULL);
	pthread_create(&tid_update, NULL, &update_file, NULL);

	// records Server builds 4 threads
#if(RECORD_PRINTF == 1)
    while(rcdFileBusy == 1){}
	rcdFileBusy = 1;
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	if(fp_rcd != NULL) {
	    fputs("Server Build 3 ethscan threads and 1 update_file thread.\n", fp_rcd); 
	    fclose(fp_rcd);
	}
	rcdFileBusy = 0;
#endif
	
	// block main thread and wait for child threads to finish executing.
    pthread_join(tid_1, NULL);   
    pthread_join(tid_2, NULL);
    pthread_join(tid_3, NULL);  
	pthread_join(tid_update, NULL); 

    // release the socket resources.
	WSACleanup();    
	return 0;    
}

/******************************* update_file ***********************************
  * function： update the files with local current clock every 5000 ms. 
*/
void * update_file()
{
	time_t t;
    char * ptime;
	FILE *fp = NULL;
	FILE *fp_rcd = NULL;

    while(1)
    {
        t = time(NULL);
        ptime = ctime(&t);
		//strcpy(ptime, ctime(&t));

        while(fileBusy[0] == 1) {}
		fileBusy[0] = 1;
     	fp = fopen("C:\\serverfile\\good.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are good!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
        fileBusy[0] = 0;

		while(fileBusy[1] == 1) {}
		fileBusy[1] = 1;
	    fp = fopen("C:\\serverfile\\friend.txt", "w+");
		if(fp != NULL) {
	        fputs(" We are good friends.", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
		fileBusy[1] = 0;

        while(fileBusy[2] == 1) {}
		fileBusy[2] = 1;
	    fp = fopen("C:\\serverfile\\better.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are getting better!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
		fileBusy[2] = 0;

        while(fileBusy[3] == 1) {}
		fileBusy[3] = 1;
	    fp = fopen("C:\\serverfile\\best.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are the best!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		} 
		fileBusy[3] = 0;

		// record Server creates 4 files
#if(RECORD_PRINTF == 1)
        while(rcdFileBusy == 1){}
	    rcdFileBusy = 1;
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
		if(fp_rcd != NULL) {
			fputs("Update 4 file.\n", fp_rcd);
	        fclose(fp_rcd);
		} 
		rcdFileBusy = 0; 
#endif 
        Sleep(5000); // sleep 5000 ms
    }
}

/*********************************** ethscan **********************************
  * function： scan and wait request from client to build a connection . 
*/
void *ethscan()
{
    char Sendbuf[SEND_LENGTH];
    char Receivebuf[RECEIVE_LENGTH];
    int SendLen;
    int ReceiveLen;
    int Length; 
	int ReceiveTimes = 0;
	char ReceiveTimesBuf[11];
	FILE *fp = NULL;
    char filePath[100];
    int Current_Port;
    time_t t;
    char * ptime;
	u_short i;
 	
    SOCKET socket_server;
    SOCKET socket_receive; 

    SOCKADDR_IN Server_add;
    SOCKADDR_IN Client_add;

    // Server is multi_threading, each thread(connection) has a different PORT in sequence.
    Current_Port = server_ports[connect_number++ % 5];

    // Server connection
    // step_1: build socket according fixed IP and assigned PORT.
	Server_add.sin_family = AF_INET;
	Server_add.sin_addr.S_un.S_addr = inet_addr(ServerIP);
	Server_add.sin_port = htons(Current_Port);
	socket_server = socket(AF_INET, SOCK_STREAM, 0);
    
    // step_2: bind 
	if (bind(socket_server, (SOCKADDR*)&Server_add, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		printf("Bind failure.\n");
	}
 
    // step_3: listen
	if (listen(socket_server, 5) < 0) {
		printf("Listen failure.\n");
	}
	
    // step_4: waiting to accept the client's connection request
	Length = sizeof(SOCKADDR);
	socket_receive = accept(socket_server, (SOCKADDR*)&Client_add, &Length);
	if (socket_receive == SOCKET_ERROR)	{
		printf("Accept connection failure.");

        // records connect failure
#if(RECORD_PRINTF == 1)		
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			itoa(Current_Port, tempBuff, 10);
		    strcpy(rcdBuff, tempBuff);
			strcat(rcdBuff, " connection failure.");
			fputs(rcdBuff, fp_rcd);
			fclose(fp_rcd);
		}
#endif
	}

	while (1)
	{
        // get local clock
        t = time(NULL);
        ptime = ctime(&t); 
        
		// step_5: waiting to receive data from the connection
		ReceiveLen = recv(socket_receive, Receivebuf, RECEIVE_LENGTH, 0);
		if (ReceiveLen < 0) {
			printf("Receive failure.\n");
			printf("Program Exit!\n");
#if(RECORD_PRINTF == 1)
			strcpy(rcdBuff, "Receive failure.\n");
			strcat(rcdBuff, "Program Exit!\n");
#endif
            Sleep(5000); // display program exit notes for 5000 ms
			break;
		}
		else {
            printf("%d ",Current_Port);
			printf("client says: %s, ", Receivebuf);

			// organize content, example format: 5--6 client say: good.txt,
#if(RECORD_PRINTF == 1)
			itoa(Current_Port, tempBuff, 10);
			strcpy(rcdBuff, tempBuff);
			strcat(rcdBuff, " client says: ");
			strcat(rcdBuff, Receivebuf);
			//strcat(rcdBuff, "\n");
			strcat(rcdBuff, ", ");
#endif
		}        
		
        ReceiveTimes++;	
		itoa(ReceiveTimes, ReceiveTimesBuf, 10);
        strcat(ReceiveTimesBuf, " times,\n");
		printf("%s", ReceiveTimesBuf);

        // records content from Client
#if(RECORD_PRINTF == 1)
        while(rcdFileBusy == 1){}
	    rcdFileBusy = 1;
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			fputs(rcdBuff, fp_rcd);  // record content, example format: 5--6 client say: good.txt,
			itoa(ReceiveTimes, ReceiveTimesBuf, 10);
            strcat(ReceiveTimesBuf, " times, ");
			fputs(ReceiveTimesBuf, fp_rcd);
			fclose(fp_rcd);
		}
		rcdFileBusy = 0;
#endif

        // open file according to file's name
		fp = NULL;
		if((strcmp(Receivebuf,"good.txt")==0) || (strcmp(Receivebuf,"good")==0)) {
			i = 0;
			while(fileBusy[i] == 1) {}
		    fileBusy[i] = 1;
		    fp = fopen("C:\\serverfile\\good.txt", "r");		
		}
		else if ((strcmp(Receivebuf,"friend.txt")==0) || (strcmp(Receivebuf,"friend")==0)) {
			i = 1;
			while(fileBusy[i] == 1) {}
		    fileBusy[i] = 1;
		    fp = fopen("C:\\serverfile\\friend.txt", "r");

		}	
		else if ((strcmp(Receivebuf,"better.txt")==0) || (strcmp(Receivebuf,"better") == 0)) {
			i = 2;
			while(fileBusy[i] == 1) {}
		    fileBusy[i] = 1;
		    fp = fopen("C:\\serverfile\\better.txt", "r");
		}	
		else if ((strcmp(Receivebuf,"best.txt")==0) || (strcmp(Receivebuf,"best")==0)) {
			i = 3;
			while(fileBusy[i] == 1) {}
		    fileBusy[i] = 1;
		    fp = fopen("C:\\serverfile\\best.txt", "r");
		}	
		else {
			i = MAX_FILE_NUMBER;
			printf("File name is incorrect.");
			send(socket_receive, "File name is incorrect.", 50, 0);
			continue;
		}
        if(fp != NULL) {
			fgets(Sendbuf, SEND_LENGTH, (FILE*)fp);	
            fclose(fp);
		}
		if(i < MAX_FILE_NUMBER) {
			fileBusy[i] = 0;
		}
		// send file+clock to client
		printf("send file content: %s\n",Sendbuf);
        //strcat(Sendbuf, ptime); // clock has added to file in main funciton
		SendLen = send(socket_receive, Sendbuf, 100, 0);
		if (SendLen < 0) {
			printf("Send Failure\n");
		}
		// records file content
#if(RECORD_PRINTF == 1)	
        while(rcdFileBusy == 1){}
	    rcdFileBusy = 1;	
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			fputs(Sendbuf, fp_rcd);
			//fputs("\n",fp_rcd);
			fclose(fp_rcd);
		}
	    rcdFileBusy = 0;
#endif	
	}
	closesocket(socket_receive);
	closesocket(socket_server);
}

/*****************************is_ipv4_addr() function ****************************
  * function： judge if the IP address pointed by *ip is valid.
  * return:    0 - valid IP, (-1) - invalid IP  
*/
int is_ipv4_addr(char *ip)
{
	if (ip == NULL || ip[0] == '0' || ip[0] == '\0') {
		return -1;
	}

	for (int i = 0, count = 0; i < strlen(ip); i++) {
		if ((ip[i] != '.') && (ip[i] < '0' || ip[i] > '9')) {
			return -1;
		}
		if (ip[i] == '.') {
			count++;
			if (count > 3) {
				return -1;
			}
		}
	}

	int ip_num[4] = {-1, -1, -1, -1};
	char ip_s[4][4];
	memset(ip_s, 0, sizeof(char[4]) * 4);

	sscanf(ip, "%[^.].%[^.].%[^.].%[^ ]", ip_s[0], ip_s[1], ip_s[2], ip_s[3]);
	sscanf(ip_s[0], "%d", &ip_num[0]);
	sscanf(ip_s[1], "%d", &ip_num[1]);
	sscanf(ip_s[2], "%d", &ip_num[2]);
	sscanf(ip_s[3], "%d", &ip_num[3]);

	for (int i = 0; i < 4; i++) {
		if (strlen(ip_s[i]) == 0 || (ip_s[i][0] == '0' && ip_s[i][1] != '\0') || ip_num[i] < 0 || ip_num[i] > 255) {
			return -1;
		}
	}

	return 0;
}
