/*******************************************************************************
 *  File：Server
 *  Function: Display Server IP address and Port
 *            Display files name stored in the directory
 *            Send the file content to Client
 ******************************************************************************/
#include <stdio.h>
#include <winsock.h>
#include <process.h>
#include <string.h>
#include <pthread.h>
#include <windows.h>
#include <time.h>
//#include <winsock2.h>

// ******************************** macro define *******************************
#define FILE_PATH           "C:\\serverfile\\"
#define SEND_length         1024
#define RECEIVE_length      1024
#define RECORD_PRINTF       1
#define MAX_FILE_NUMBER     4

// **************************** global parameters define ***********************
const int server_ports[5] = {5006,5007,5008,5009,5010};
static char connect_number = 0;		// every child thread allocate a different port
char server_ip[25];
char rcdfile_busy = 0; // file busy flag
char file_busy[MAX_FILE_NUMBER];
FILE *fp_rcd = NULL;  // record file handle pointer
char rcd_buff[1024];
char temp_buff[100];

// ****************************** function declaration *************************
void * ethscan();
void * update_file();
int is_ipv4_addr(char *ip);
void server_build_files(void);
void rcd_ip_ports(char * server_ip);


/******************************* main function ***********************************
  * function： program entry: main(). 
*/
int main(void)
{
    FILE *fp = NULL;
    pthread_t tid_1, tid_2, tid_3, tid_4, tid_5, tid_update;
    time_t t;
	char ptime[50];
    unsigned long longserver_ip;
    WORD version_requested;
    WSADATA wsa_data;
    int error;
	int i;

	/* To use sockets in Windows, we need to load the socket library (socket environment) 
	first(WSAStartup) , and release the socket resources in the end.(WSACleanup)*/
	version_requested = MAKEWORD(2, 2);
    error = WSAStartup(version_requested, &wsa_data);	
    if (error != 0)
	{
		printf("WSAStartup failed with error: %d\n", error);
		return 0;
	}
	if (LOBYTE(wsa_data.wVersion) != 2 || HIBYTE(wsa_data.wVersion) != 2)
	{
		printf("Could not find a usable version of Winsock.dll\n");
		WSACleanup();
		return 0;
	}	

	for(i=0; i<4; i++) {
		file_busy[i] = 0;
	}

	server_build_files();	// get files in Server

    // records Server build 4 new files
#if(RECORD_PRINTF == 1)	
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "w+");
	if(fp_rcd != NULL) {
		fputs("Server WSAStartup run success.\n", fp_rcd);
		fputs("file's directory is C:\\serverfile\n", fp_rcd);
	    fclose(fp_rcd); 
	}
#endif
	

    // indicates to input Server IP adress
    printf("Server is On!\n");
	printf("Please set Server IP: ");
    scanf("%s", server_ip);
    while(is_ipv4_addr(server_ip) == -1) {
        printf("IP address is invalid!\n");   
        printf("Please input Server IP you will connect:");
        scanf("%s", server_ip);
    }

	printf("Server's IP address is %s.\n", server_ip);
	if(inet_addr(server_ip) == -1)
	{
		printf("\nServer's IP is Invalid!!!  %s.\n");
		printf("Please restart the server and input Valid IP address. \n\n");
	}
    printf("Server Ports are: %d, %d, %d, %d, %d.\n", server_ports[0], server_ports[1],\
            server_ports[2],  server_ports[3],  server_ports[4]);
	printf("Please connect Server and input the file name you want to receive:\n");
	printf("good.txt, friend.txt, better.txt, best.txt\n");  

    rcd_ip_ports(server_ip); // records Server IP adress and Ports
    
    // builds 3 ethscan threads and 1 update_file thread.
    pthread_create(&tid_1, NULL, &ethscan, NULL);
    pthread_create(&tid_2, NULL, &ethscan, NULL);
    pthread_create(&tid_3, NULL, &ethscan, NULL);
	pthread_create(&tid_4, NULL, &ethscan, NULL);
    pthread_create(&tid_5, NULL, &ethscan, NULL);
	pthread_create(&tid_update, NULL, &update_file, NULL);

	// records Server builds 4 threads
#if(RECORD_PRINTF == 1)
    while(rcdfile_busy == 1){}
	rcdfile_busy = 1;
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	if(fp_rcd != NULL) {
	    fputs("Server Build 3 ethscan threads and 1 update_file thread.\n", fp_rcd); 
	    fclose(fp_rcd);
	}
	rcdfile_busy = 0;
#endif
	
	// block main thread and wait for child threads to finish executing.
    pthread_join(tid_1, NULL);   
    pthread_join(tid_2, NULL);
    pthread_join(tid_3, NULL);
	pthread_join(tid_4, NULL);
    pthread_join(tid_5, NULL);    
	pthread_join(tid_update, NULL); 

    // release the socket resources.
	WSACleanup();    
	return 0;    
}

/******************************* update_file ***********************************
  * function： update the files with local current clock every 5000 ms. 
*/
void * update_file()
{
	time_t t;
    char * ptime;
	FILE *fp = NULL;
	FILE *fp_rcd = NULL;

    while(1)
    {
        t = time(NULL);
        ptime = ctime(&t);

        while(file_busy[0] == 1) {}
		file_busy[0] = 1;
     	fp = fopen("C:\\serverfile\\good.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are good!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
        file_busy[0] = 0;

		while(file_busy[1] == 1) {}
		file_busy[1] = 1;
	    fp = fopen("C:\\serverfile\\friend.txt", "w+");
		if(fp != NULL) {
	        fputs(" We are good friends.", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
		file_busy[1] = 0;

        while(file_busy[2] == 1) {}
		file_busy[2] = 1;
	    fp = fopen("C:\\serverfile\\better.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are getting better!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		}
		file_busy[2] = 0;

        while(file_busy[3] == 1) {}
		file_busy[3] = 1;
	    fp = fopen("C:\\serverfile\\best.txt", "w+");
		if(fp != NULL) {
	        fputs(" You are the best!", fp);
            fputs(ptime, fp);
	        fclose(fp);
		} 
		file_busy[3] = 0;

		// record Server creates 4 files
#if(RECORD_PRINTF == 1)
        while(rcdfile_busy == 1){}
	    rcdfile_busy = 1;
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
		if(fp_rcd != NULL) {
			fputs("Update 4 file.\n", fp_rcd);
	        fclose(fp_rcd);
		} 
		rcdfile_busy = 0; 
#endif 
        Sleep(5000); // sleep 5000 ms
    }
}

/*********************************** ethscan **********************************
  * function： scan and wait request from client to build a connection . 
*/
void *ethscan()
{
    char send_buff[SEND_length];
    char receive_buff[RECEIVE_length];
    int send_len;
    int receive_len;
    int length; 
	int receive_times = 0;
	char receive_timesBuf[11];
	FILE *fp = NULL;
    char file_path[100];
    int current_port;
    time_t t;
    char * ptime;
	u_short i;
 	
    SOCKET socket_server;
    SOCKET socket_receive; 

    SOCKADDR_IN server_addr;
    SOCKADDR_IN client_addr;

    // Server is multi_threading, each thread(connection) has a different PORT in sequence.
    current_port = server_ports[connect_number++ % 5];

    // Server connection
    // step_1: build socket according fixed IP and assigned PORT.
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.S_un.S_addr = inet_addr(server_ip);
	server_addr.sin_port = htons(current_port);
	socket_server = socket(AF_INET, SOCK_STREAM, 0);
    
    // step_2: bind 
	if (bind(socket_server, (SOCKADDR*)&server_addr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		printf("Bind failure.\n");
	}
 
    // step_3: listen
	if (listen(socket_server, 5) < 0) {
		printf("Listen failure.\n");
	}
	
    // step_4: waiting to accept the client's connection request
	length = sizeof(SOCKADDR);
	socket_receive = accept(socket_server, (SOCKADDR*)&client_addr, &length);
	if (socket_receive == SOCKET_ERROR)	{
		printf("Accept connection failure.");

        // records connect failure
#if(RECORD_PRINTF == 1)		
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			itoa(current_port, temp_buff, 10);
		    strcpy(rcd_buff, temp_buff);
			strcat(rcd_buff, " connection failure.");
			fputs(rcd_buff, fp_rcd);
			fclose(fp_rcd);
		}
#endif
	}

	while (1)
	{
        // get local clock
        t = time(NULL);
        ptime = ctime(&t); 
        
		// step_5: waiting to receive data from the connection
		receive_len = recv(socket_receive, receive_buff, RECEIVE_length, 0);
		if (receive_len < 0) {
			printf("Receive failure.\n");
			printf("Program Exit!\n");
#if(RECORD_PRINTF == 1)
			strcpy(rcd_buff, "Receive failure.\n");
			strcat(rcd_buff, "Program Exit!\n");
#endif
            Sleep(5000); // display program exit notes for 5000 ms
			break;
		}
		else {
            printf("%d ",current_port);
			printf("client says: %s, ", receive_buff);

			// organize content, example format: 5--6 client say: good.txt,
#if(RECORD_PRINTF == 1)
			itoa(current_port, temp_buff, 10);
			strcpy(rcd_buff, temp_buff);
			strcat(rcd_buff, " client says: ");
			strcat(rcd_buff, receive_buff);
			//strcat(rcd_buff, "\n");
			strcat(rcd_buff, ", ");
#endif
		}        
		
        receive_times++;	
		itoa(receive_times, receive_timesBuf, 10);
        strcat(receive_timesBuf, " times,\n");
		printf("%s", receive_timesBuf);

        // records content from Client
#if(RECORD_PRINTF == 1)
        while(rcdfile_busy == 1){}
	    rcdfile_busy = 1;
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			fputs(rcd_buff, fp_rcd);  // record content, example format: 5--6 client say: good.txt,
			itoa(receive_times, receive_timesBuf, 10);
            strcat(receive_timesBuf, " times, ");
			fputs(receive_timesBuf, fp_rcd);
			fclose(fp_rcd);
		}
		rcdfile_busy = 0;
#endif

        // open file according to file's name
		fp = NULL;
		if((strcmp(receive_buff,"good.txt")==0) || (strcmp(receive_buff,"good")==0)) {
			i = 0;
			while(file_busy[i] == 1) {}
		    file_busy[i] = 1;
		    fp = fopen("C:\\serverfile\\good.txt", "r");		
		}
		else if ((strcmp(receive_buff,"friend.txt")==0) || (strcmp(receive_buff,"friend")==0)) {
			i = 1;
			while(file_busy[i] == 1) {}
		    file_busy[i] = 1;
		    fp = fopen("C:\\serverfile\\friend.txt", "r");

		}	
		else if ((strcmp(receive_buff,"better.txt")==0) || (strcmp(receive_buff,"better") == 0)) {
			i = 2;
			while(file_busy[i] == 1) {}
		    file_busy[i] = 1;
		    fp = fopen("C:\\serverfile\\better.txt", "r");
		}	
		else if ((strcmp(receive_buff,"best.txt")==0) || (strcmp(receive_buff,"best")==0)) {
			i = 3;
			while(file_busy[i] == 1) {}
		    file_busy[i] = 1;
		    fp = fopen("C:\\serverfile\\best.txt", "r");
		}	
		else {
			i = MAX_FILE_NUMBER;
			printf("File name is incorrect.");
			send(socket_receive, "File name is incorrect.", 50, 0);
			continue;
		}
        if(fp != NULL) {
			fgets(send_buff, SEND_length, (FILE*)fp);	
            fclose(fp);
		}
		if(i < MAX_FILE_NUMBER) {
			file_busy[i] = 0;
		}
		// send file+clock to client
		printf("send file content: %s\n",send_buff);
        //strcat(send_buff, ptime); // clock has added to file in main funciton
		send_len = send(socket_receive, send_buff, 100, 0);
		if (send_len < 0) {
			printf("Send Failure\n");
		}
		// records file content
#if(RECORD_PRINTF == 1)	
        while(rcdfile_busy == 1){}
	    rcdfile_busy = 1;	
	    fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	    if(fp_rcd != NULL) {
			fputs(send_buff, fp_rcd);
			fclose(fp_rcd);
		}
	    rcdfile_busy = 0;
#endif	
	}
	closesocket(socket_receive);
	closesocket(socket_server);
}

/*****************************is_ipv4_addr() function ****************************
  * function： judge if the IP address pointed by *ip is valid.
  * return:    0 - valid IP, (-1) - invalid IP  
*/
int is_ipv4_addr(char *ip)
{
	if (ip == NULL || ip[0] == '0' || ip[0] == '\0') {
		return -1;
	}

	for (int i = 0, count = 0; i < strlen(ip); i++) {
		if ((ip[i] != '.') && (ip[i] < '0' || ip[i] > '9')) {
			return -1;
		}
		if (ip[i] == '.') {
			count++;
			if (count > 3) {
				return -1;
			}
		}
	}

	int ip_num[4] = {-1, -1, -1, -1};
	char ip_s[4][4];
	memset(ip_s, 0, sizeof(char[4]) * 4);

	sscanf(ip, "%[^.].%[^.].%[^.].%[^ ]", ip_s[0], ip_s[1], ip_s[2], ip_s[3]);
	sscanf(ip_s[0], "%d", &ip_num[0]);
	sscanf(ip_s[1], "%d", &ip_num[1]);
	sscanf(ip_s[2], "%d", &ip_num[2]);
	sscanf(ip_s[3], "%d", &ip_num[3]);

	for (int i = 0; i < 4; i++) {
		if (strlen(ip_s[i]) == 0 || (ip_s[i][0] == '0' && ip_s[i][1] != '\0') || ip_num[i] < 0 || ip_num[i] > 255) {
			return -1;
		}
	}

	return 0;
}

/************************server_build_files() function *************************
  * function： build 4 files in C:\serverfile.
*/
void server_build_files(void)
{
	FILE *fp = NULL;

    // builds 4 files for Server to transfer.
	fp = fopen("C:\\serverfile\\good.txt", "w+");
	fputs(" You are good!", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\friend.txt", "w+");
	fputs(" We are good friends.", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\better.txt", "w+");
	fputs(" You are getting better!", fp);
	fclose(fp);
	fp = fopen("C:\\serverfile\\best.txt", "w+");
	fputs(" You are the best!", fp);
	fclose(fp); 
}

/************************rcd_ip_ports() function *************************
  * function： record IP address and default Ports in file.
*/
void rcd_ip_ports(char * server_ip)
{
    char rcd_buff[100];
	char temp_buff[10];
    FILE *fp_rcd = NULL;

#if(RECORD_PRINTF == 1)	
	fp_rcd = fopen("C:\\serverfile\\ServerRecord.txt", "a+");
	if(fp_rcd != NULL) {
		fputs("Server IP:", fp_rcd); 
		fputs(server_ip, fp_rcd); 
		fputs("\n", fp_rcd);

		strcpy(rcd_buff, "Ports:");
		for(int i=0; i<5; i++) {
        	itoa(server_ports[i], temp_buff, 10);
			strcat(rcd_buff, temp_buff);
			strcat(rcd_buff, ",");
		}
		strcat(rcd_buff, "\n");
		fputs(rcd_buff, fp_rcd);
		fclose(fp_rcd);
	}
#endif	
}